import { MenuFoldOutlined, MenuUnfoldOutlined } from "@ant-design/icons"
import { Button } from "antd"
import { Header } from "antd/es/layout/layout"

export default function MyHeader() {
  return (
    <Header
    style={{background:'#00152A'}}
    >
           {/* <Button type='primary' 
       style={
        {
          fontSize:'16px',
          width:64,
          height:64
        }
      } >

    </Button> */}
    </Header>  )
}
